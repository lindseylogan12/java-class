/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.fors;

/**
 *
 * @author lindseylogan
 */
public class ForByFor {
    
    public static void main(String[] args) {
        
       /* for (int i = 0; i < 3; i++) {
            System.out.print("|");
            
            for (int j = 0; j < 3; j++){
                for (int k = 0; k < 3; k++){
                    System.out.print("*");
                }
                System.out.print("|");
            }
            System.out.println("");
        } //both fors nested within one umbrella 'for'
        
       */ 
        
       for (int i = 0; i < 3; i++) {
           System.out.print("|");       // beginning one - no need to touch
           
           for (int j = 0; j < 3; j+=3){
               for (int k = 0; k < 3; k++) {
                       System.out.print("*");
               }
               System.out.print("|"); // line 2 3 4 in row 1 2 3 -- no need to touch
               for (int l = 2; l < 5; l++) {
                   System.out.print("$");
               }
               System.out.print("|");
               for (int p = 4; p < 7; p++) {
                   System.out.print("@");
               }
               System.out.print("|");
           }
           System.out.println(""); //how it ends with a space -- no need to touch this
       }
    }
}
