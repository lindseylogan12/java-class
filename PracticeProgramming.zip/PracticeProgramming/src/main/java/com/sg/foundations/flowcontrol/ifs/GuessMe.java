/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.ifs;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class GuessMe {
    public static void main(String[] args) {
        
        int choice = 5;
        int userChoice;
        
        Scanner myScanner = new Scanner(System.in); 
        
        System.out.println("Please pick a whole number and enter it below: ");
        userChoice = Integer.parseInt(myScanner.nextLine());
        
        System.out.println("You entered: " + userChoice);
        
        if (userChoice == choice) {
            System.out.println("You guessed my number!");
        }
        
        if (userChoice < choice) {
            System.out.println("Too low, I chose " + choice);
        }
        
        if (userChoice > choice) {
            System.out.println("Too high, I chose " + choice);
        }
    }
}
