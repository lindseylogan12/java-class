/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.ifs;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class BirthStones {
    public static void main(String[] args) {
         int month;
         
         Scanner myScanner = new Scanner(System.in);
         
         System.out.println("What month's birthstone do you want to know?");
         month = Integer.parseInt(myScanner.nextLine());
         
         if (month == 1) {
             System.out.println("Garnet");
         } else if (month == 2) {
             System.out.println("Amethyst");
         } else if (month == 3) {
             System.out.println("Aquamarine");    
         } else if (month == 4) {
             System.out.println("Diamond");
         } else if (month == 5) {
             System.out.println("Emerald");
         } else if (month == 6) {
             System.out.println("Pearl");
         } else if (month == 7) {
             System.out.println("Ruby");    
         } else if (month == 8) {
             System.out.println("Peridot");
         } else if (month == 9) {
             System.out.println("Sapphire");
         } else if (month == 10) {
             System.out.println("Opal");
         } else if (month == 11) {
             System.out.println("Topaz");    
         } else if (month == 12) {
             System.out.println("Turquoise");
         } else {
             System.out.println("That input doesn't correspond with a month.");
         }
    }
}
