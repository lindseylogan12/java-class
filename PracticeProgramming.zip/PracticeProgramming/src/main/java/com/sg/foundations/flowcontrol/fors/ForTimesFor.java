/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.fors;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class ForTimesFor {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        int tally = 0;
        
        System.out.println("Which times table should I recite?");
        int action = sc.nextInt();
        
        for (int i = 1; i < 16; i++) {
            System.out.println(i + " * " + action + " is: ");
            int answer = sc.nextInt();
            
            if (answer == (i * action)) {
                System.out.println("Correct!");
                tally++;
                
            } else {
                System.out.println("Sorry, no, the correct answer is: " + (i * action));
            }
            
            }
        if (tally <= 7) {
            System.out.println("You need to study more!");
        } else if (tally >= 13) {
            System.out.println("Congratulations!! You got " + tally + " right!");
        }
         
        }
    }
   

