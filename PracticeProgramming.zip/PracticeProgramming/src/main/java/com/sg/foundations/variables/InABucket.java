/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.variables;

/**
 *
 * @author lindseylogan
 */
public class InABucket {
    public static void main(String[] args) {
        String walrus;
        double piesEaten;
        float weightOfTeacupPig;
        int grainsOfSand;
        
        walrus = "Sir Leroy Jenkins III";
        piesEaten = 42.1;
        weightOfTeacupPig = 6.9f;
        grainsOfSand = 21;
        
        System.out.println("Meet my pet walrus, " + walrus);
        System.out.print("He was a bit hungry today, he ate this many pies: ");
        System.out.println(piesEaten);
        System.out.println("The weight of the pig that won the smallest pig competition was: ");
        System.out.println(weightOfTeacupPig + " ounces! That's the same weight as " + grainsOfSand + " grands of sand!");
        
    }
}
