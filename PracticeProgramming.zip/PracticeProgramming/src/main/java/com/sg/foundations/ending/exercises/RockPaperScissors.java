/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.ending.exercises;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class RockPaperScissors {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
       
        
        System.out.print("How many rounds would you like to play? (1 - 10): ");
        int rounds = Integer.parseInt(sc.nextLine());
        
        while (rounds < 1 || rounds > 10) {
            System.out.print("Out of range - please enter a number 1 - 10: ");
            rounds = sc.nextInt();
            break;
        }
           
         System.out.println(rounds + " it is! - Let's play!");
         
        int userCount = 0;
        int compCount = 0;
         
       for (int i = 0; i < rounds; i++) {
         
        String userChoice = userPlay();
        String compChoice = compPlay();
        
         
        System.out.println("You played: " + userChoice);
       
        System.out.println("I played: " + compChoice);
        
        
       if (userChoice.equals(compChoice)) {
           System.out.println("Draw!");
       } 
       
       if (userChoice == "Rock" && compChoice == "Paper") {
           System.out.println("You lose!");
           compCount++;
       }
       
       if (userChoice == "Rock" && compChoice == "Scissors") {
           System.out.println("You win!");
           userCount++;
       }
       
       if (userChoice == "Paper" && compChoice == "Rock") {
           System.out.println("You win!");
           userCount++;
       }
       
       if (userChoice == "Paper" && compChoice == "Scissors") {
           System.out.println("You lose!");
           compCount++;
       }
       
       if (userChoice == "Scissors" && compChoice == "Rock") {
           System.out.println("You lose!");
           compCount++;
       }
       
       if (userChoice == "Scissors" && compChoice == "Paper") {
           System.out.println("You win!");
           userCount++;
       }
       
       }
       
        if (userCount > compCount) {
            System.out.println("Congratualations, you won " + userCount + " time(s)!");
        }
    }
    
    public static String compPlay(){
       Random myRand = new Random();
       
       String play[] = { "Rock", "Paper", "Scissors" };
       int randPlay = myRand.nextInt(play.length - 1);
       return play[randPlay];
    }
    
    public static String userPlay(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("\nReady? \nRock... Paper... Scissors... SHOOT: ");
        int userPlay = sc.nextInt();
        
        String userMove;
        
        if (userPlay == 1) {
            userMove = "Rock";
        } else if (userPlay == 2){
            userMove = "Paper";
        } else {
            userMove = "Scissors";
            }
        return userMove;
          
    }
     
    
}
