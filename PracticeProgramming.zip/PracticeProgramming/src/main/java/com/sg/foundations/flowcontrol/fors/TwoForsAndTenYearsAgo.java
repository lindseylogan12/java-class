/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.fors;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class TwoForsAndTenYearsAgo {
 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("What year would you like to count back from? ");
        int year = sc.nextInt();
        
        for (int i = 0; i <= 10; i++) {
            System.out.println(i + " years would be " + (year - i));        // this way makes more sense to me
        }
        
        System.out.println("\nI can count backwards using a different way too...");
        
        for (int i = year; i >= year - 20; i--) {
            System.out.println( (year - i) + " years ago would be " + i);
        }
    }
}
