/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.whiles;

import java.util.Random;

/**
 *
 * @author lindseylogan
 */
public class MaybeItLovesMe {
    
    public static void main(String[] args) {
        
        Random myRandom = new Random();
        
        int lovesMe = 0;
        int lovesNot = 0;
        
        int petals = myRandom.nextInt(89) + 13;
        
        System.out.println("Here it goes...");
      
        
        boolean love = true;
        
        
        do {
            if (petals % 2 == 1) {
                love = false;
            }    
            
            System.out.println("He loves me");
                petals--;
                lovesMe++;
                
            if (!love) {
                System.out.println("He loves me NOT!");
                petals--;
                lovesNot++;
            }
            
        } while (lovesMe < petals);
          
            
        
    
        
        //relays message depending on last pedal
        
        if (petals % 2 == 1) {
            System.out.println("Awww, bummer.");
        } else {
            System.out.println("I knew it! He loves me!");
        }
            
           System.out.println(petals);

}
}
