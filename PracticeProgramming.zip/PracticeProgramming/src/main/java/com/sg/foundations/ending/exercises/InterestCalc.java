/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.ending.exercises;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class InterestCalc {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        float interestRate;
        float principal;
        float years;
        
        interestRate = readValue("Please input the annual interest rate: ");
        principal = readValue("Please input the initial amount of principal: ");
        years = readValue("How many years do you want to keep this money invested?: ");
        
        //caclulations below
        
        float earnedQuarter = (principal * (1 + ((interestRate / 4) / 100))) - principal;
        float earnedYear = earnedQuarter * 4;
        float ending = principal + earnedYear;
        float beginning = ending;
        
        
        
        for (int i = 1; i <= years; i++){ 
        System.out.println("Year: " + i);
        System.out.println("Began with $" + beginning);
        System.out.println("Earned $" + earnedYear*i);
        System.out.println("Ended with $" + ending);
            
        }   
    }
    
    public static float readValue(String prompt) {
        Scanner sc = new Scanner(System.in);
        System.out.print(prompt);
        String input = sc.nextLine();
        float floatVal = Float.parseFloat(input);
        return floatVal;
    }
    
}
