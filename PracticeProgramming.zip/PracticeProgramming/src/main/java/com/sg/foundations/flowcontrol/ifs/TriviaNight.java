/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.ifs;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class TriviaNight {
    
    public static void main(String[] args) {
        
        int answer, answer2, answer3;
        int correct = 0;
        
        Scanner myScanner = new Scanner(System.in);
        
        System.out.println("Question 1:");
        System.out.println("How many seasons of Keeping Up with the Kardashians are there?");
        System.out.println("1) 8 seasons");
        System.out.println("2) 20 seasons");
        System.out.println("3) 25 seasons");
        
        
        answer =  Integer.parseInt(myScanner.nextLine());
        System.out.println("Your answer: " + answer);
        System.out.println("\n");
       
        
        System.out.println("Question 2:");
        System.out.println("How hosts the show 'Family Feud'?");
        System.out.println("1) Steve Harvey");
        System.out.println("2) Ronald Reagan");
        System.out.println("3) Timothy Chamelot");
        
        answer2 =  Integer.parseInt(myScanner.nextLine());
        System.out.println("Your answer: " + answer2);
        System.out.println("\n");
        
        
        System.out.println("Question 3:");
        System.out.println("What is the square root of 12");
        System.out.println("1) 24");
        System.out.println("2) 64");
        System.out.println("3) 144");
        
        answer3 =  Integer.parseInt(myScanner.nextLine());
        System.out.println("Your answer: " + answer3);
        System.out.println("\n");
        
        
        if (answer == 2) {
            correct++;
        }
        
        if (answer2 == 1) {
            correct++;
        }
        if (answer3 == 3) {
            correct++;
        }
        
        
        System.out.println("You answered " + correct + " correctly!");
        
        if (correct == 3) {
            System.out.println("Congrats, you answered all questions right!");
        }
    }
}
