/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.fors;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class TheCount {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Start at: ");
        int start = sc.nextInt();
        
        System.out.print("Stop at: ");
        int stop = sc.nextInt();
        
        System.out.print("Count by: ");
        int count = sc.nextInt();
        
        for (int i = start; i < stop + 1;i += count) {
            System.out.print(i + " ");
        }
    }
}
