/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.arrays;

import java.util.Arrays;

/**
 *
 * @author lindseylogan
 */
public class FruitSalad {
    
    public static void main(String[] args) {
        String[] fruit = {"Kiwi Fruit", "Gala Apple", "Granny Smith Apple", "Cherry Tomato", "Gooseberry", "Beefsteak Tomato", "Braeburn Apple", "Blueberry", "Strawberry", "Navel Orange", "Pink Pearl Apple",  "Raspberry", "Blood Orange", "Sungold Tomato", "Fuji Apple", "Blackberry", "Banana", "Pineapple", "Florida Orange", "Kiku Apple", "Mango", "Satsuma Orange", "Watermelon", "Snozzberry"};

        String[] fruitSalad = new String[fruit.length];
        
        int numBerries = 0; // as many berries as possible
        int numApples = 0;  // no more than three kinds of apples
        int numOranges = 0;  // no more than 2 kinds of oranges
        int numTomatoes = 0; //no tomatoes allowed
        int totalKind = 0;  // no more than 12 kinds of fruit

        // Code Recipe for fruit salad should go here!

        for (int i = 0; i < fruit.length; i++){
            if (fruit[i].contains("berry")){
               numBerries++; 
               fruitSalad[i] = fruit[i];
            }
            if (fruit[i].contains("Apple")){
                numApples = Math.max(numApples++, 3) ;
                fruitSalad[i] = fruit[i];
            }
            if (fruit[i].contains("Orange")){
                numOranges = Math.max(numOranges++, 3) ;
                fruitSalad[i] = fruit[i];
            }
        }
        
        
        System.out.print(Arrays.toString(fruitSalad));            // null out the ones that dont qualify
        
    }
}
