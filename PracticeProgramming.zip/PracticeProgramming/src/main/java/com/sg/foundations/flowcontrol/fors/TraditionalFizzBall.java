/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.fors;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class TraditionalFizzBall {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Please input a number: ");
        int num = sc.nextInt();
        
        
        
        for (int o = 1; o <= num; o++){
           if (o % 3 == 0){
               System.out.print("fuzz ");
        } 
           if (o % 5 == 0){
               System.out.print("buzz ");
           }
           if (o % 3 != 0 || o % 5 != 0)
            System.out.println(o);
        }
        
    }
}
