/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.ifs;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class KnockKnock {
    
    public static void main(String[] args) {
        
        Scanner myScanner = new Scanner(System.in); 
        
        System.out.print("Knock Knock! Guess who!!");
        String nameGuess = myScanner.nextLine();
        
        if (nameGuess.equals("Marty McFly")) {
            System.out.println("Hey! That's right! I am back!");
            System.out.println("... from the Future.");
        } else {
            System.out.println("Dude, do I -look- like " + nameGuess);
        }
    }
}
