/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.random;

import java.util.Random;

/**
 *
 * @author lindseylogan
 */
public class FortuneCookie {
    
    public static void main(String[] args) {
        
        Random randomizer = new Random();
        
        System.out.println("What shall my fortune read me today?");
        
        int x = randomizer.nextInt(10);
        
        System.out.println("The number we choose was: " + x);
        
        switch (x) {
            case 1:
                System.out.println("All things in life came when the time is right");
                break;
            case 2:
            case 3:
            case 4:
                System.out.println("Nothing that is meant for you will ever pass you");
                break;
            case 5:
            case 6:
            case 7:
                System.out.println("Maybe you're not meant to receive your lemons right now");
                break;
            case 8:
            case 9:
            case 10:
                System.out.println("Maybe what you need is to sit outside for a while and eat a banana");
                break;
                
        }
    }
}
