/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.whiles;

/**
 *
 * @author lindseylogan
 */
public class LovesMe {
    
    public static void main(String[] args) {
        
        int lovesMe = 0;
        int lovesNot = 0;
        int petals = 34;
        
        
        System.out.println("Here it goes...");
        
        
        boolean love = true;
        while (lovesMe < petals) {
            if  (petals % 2 == 1) {
                love = false;
            }
            
            
            System.out.println("He loves me");
            petals--;
            
            if (!love) {
            System.out.println("He loves me NOT!");
            lovesNot++;
            petals--;
            }
        }
        

//relays message depending on last pedal
        if (lovesNot % 2 == 0) {
            System.out.println("Awww, bummer.");
        } else {
            System.out.println("I knew it! He loves me!");
        }
        
    }
}
