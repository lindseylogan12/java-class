/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.ifs;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class PickyEaters {
    
    public static void main(String[] args) {
        
        Scanner myScanner = new Scanner(System.in);
        
        System.out.println("How many times has it been fried?");
        int fried = Integer.parseInt(myScanner.nextLine());
        
        System.out.println("Does it have any spinach in it? y/n");
        String spinach = myScanner.nextLine();
        
        System.out.println("Is it covered in cheese? y/n");
        String cheese = myScanner.nextLine();
        
        System.out.println("How many pats of butter are on top? (#)");
        int butter = Integer.parseInt(myScanner.nextLine());
        
        System.out.println("Is it covered in chocolate? y/n");
        String chocolate = myScanner.nextLine();
        
        System.out.println("Does it have a funny name? y/n");
        String funnyName = myScanner.nextLine();
        
        System.out.println("Is it broccoli? y/n");
        String broccoli = myScanner.nextLine();
        
        
        // conditionals below 
        
        
        if (spinach.equals("y") || funnyName.equals("y")) {
            System.out.println("There's no way he will eat that!");
        } 
        
        
        if ((fried > 2 && fried < 4) && chocolate.equals("y")) {
            System.out.println("A  deep fried snickers... that'll be a hit.");
        } else if (fried == 2 && cheese.equals("y")) {
            System.out.println("Yeah, he'll sure eat fried cheesey doodles");
        }
        
        
        if (broccoli.equals("y") && butter > 6 && cheese.equals("y")) {
            System.out.println("As long as the green is hidden by the chedder");
        } else if (broccoli.equals("y")) {
            System.out.println("Green stuff might as well be thrown away.");
        }
        
        
    }
}
