/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.scanner;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class HealthyHearts {
    public static void main(String[] args) {
        
        int age, maxRate;
        float lowTarget, highTarget;
        
        Scanner myScanner = new Scanner(System.in);
        
        System.out.println("What is your age?");
        age = Integer.parseInt(myScanner.nextLine());
        
        //calculating maximum heart rate
        maxRate = 220 - age;
        
        lowTarget = 0.50f * maxRate;
        highTarget = 0.80f * maxRate;
        
        System.out.println("Your maximum heart rate should be: " + maxRate);
        System.out.println("Your target HR zone is " + lowTarget + " - " + highTarget + " beats per minute");
        
        
        
    }
}
