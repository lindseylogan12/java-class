/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.arrays;

/**
 *
 * @author lindseylogan
 */
public class ARainbow {
    public static void main(String[] args) {
        
        String[] colors = {"Red", "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet"};

        System.out.println(colors[5]);
        System.out.println(colors[3]);
        System.out.println(colors[2]);
        System.out.println(colors[1]);
        System.out.println(colors[4]);
        System.out.println(colors[0]);
        System.out.println(colors[6]);
    }
}
