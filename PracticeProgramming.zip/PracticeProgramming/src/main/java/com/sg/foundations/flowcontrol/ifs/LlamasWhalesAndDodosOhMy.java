/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.ifs;

/**
 *
 * @author lindseylogan
 */
public class LlamasWhalesAndDodosOhMy {
    public static void main(String[] args) {
        
        int llamas = 20;
        int whales = 15;
        int dodos = 0;
        
        if (dodos > 0) {
            System.out.println("Egads, I thought dodos were extinct!");
        }
        
        if (dodos < 0) {
            System.out.println("Hold on, how can we have negative dodos??");
        }
        
        if (llamas > whales) {
            System.out.println("Whales are bigger, llamas are better.");
        }
        
        if (llamas <= whales) {
            System.out.println("Brawn over brains - whales beat llamas");
        }
        
        System.out.println("There's been a huge increase in the dodo population via cloning!");
        dodos += 100;
        
        if ((whales + llamas) < dodos) {
            System.out.println("I never thought I'd see dodos rules the earth.");
        }
        
        if (llamas > whales && llamas > dodos) {
            System.out.println("Llamas are 100% victorious");
        }
    }
}
