/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.scanner;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class MiniMadLibs {
    public static void main(String[] args) {
        String noun, adjective, noun2, number, adjective2, pluralNoun, pluralNoun2, pluralNoun3, verbPresentTense, sameVerbPastTense;
        
        Scanner myScanner = new Scanner(System.in);
        
        System.out.println("Please enter two nouns:");
        noun = myScanner.nextLine();
        noun2 = myScanner.nextLine();
        
        System.out.println("Please enter 2 adjectives:");
        adjective = myScanner.nextLine();
        adjective2 = myScanner.nextLine();
        
        System.out.println("Please enter a number:");
        number = myScanner.nextLine();
        
        System.out.println("Please enter 3 plural nouns:");
        pluralNoun = myScanner.nextLine();
        pluralNoun2 = myScanner.nextLine();
        pluralNoun3 = myScanner.nextLine();
        
        System.out.println("Please enter the same verb in both present and past tense (in that order):");
        verbPresentTense = myScanner.nextLine();
        sameVerbPastTense = myScanner.nextLine();
        
        
        System.out.println("Initializing...");
        System.out.println(noun + ": the " + adjective + " frontier. These are the voyages of the starship " + noun2 + ".");
        System.out.println("It's " + number + "-year mission: to explore strange " + adjective2 + " " + pluralNoun + ", to seek out " + adjective2 + " " + pluralNoun2 + " and " + adjective2 + " " + pluralNoun3 + ",");
        System.out.println("to boldly " + verbPresentTense + " where no one has " + sameVerbPastTense + " before.");
        
    }
}
