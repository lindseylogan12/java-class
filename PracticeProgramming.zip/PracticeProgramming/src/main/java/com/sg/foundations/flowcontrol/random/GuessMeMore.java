/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.random;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class GuessMeMore {
 
    public static void main(String[] args) {
        
        Random myRandom = new Random();
        
        int userChoice;
        
        int choice = myRandom.nextInt(100 - -100) - 100;
        
        Scanner myScanner = new Scanner(System.in); 
        
        System.out.println("Please pick a whole number between -100 and 100 and enter it below: ");
        userChoice = Integer.parseInt(myScanner.nextLine());
        
        System.out.println("You entered: " + userChoice);
        
        if (userChoice == choice) {
            System.out.println("You guessed my number!");
        }
        
        if (userChoice < choice) {
            System.out.println("Too low, I chose " + choice);
        }
        
        if (userChoice > choice) {
            System.out.println("Too high, I chose " + choice);
    }
}
}
