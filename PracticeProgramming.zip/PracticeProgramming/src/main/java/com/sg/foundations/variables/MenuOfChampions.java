/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.variables;

/**
 *
 * @author lindseylogan
 */
public class MenuOfChampions {
    public static void main(String[] args) {
        
        float soup = 4.99f;
        float salad = 8.99f;
        float ribs = 14.99f;
        
        System.out.println("Welcome to Lenny's BBQ!");
        System.out.println("Today's specials include:");
        
        System.out.println("\n");
        
        System.out.println(soup + " Clam Chowder Soup");
        System.out.println(salad + " Our House Salad with Fresh Greens and a glazed Balsamic Vinagrette");
        System.out.println(ribs + " Our famous Rack of Ribs that fall off the bone");
        
    }
}
