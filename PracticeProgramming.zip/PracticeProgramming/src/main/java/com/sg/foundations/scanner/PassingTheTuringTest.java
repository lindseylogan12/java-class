/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.scanner;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class PassingTheTuringTest {
    public static void main(String[] args) {
        String name, myName, favColor, favFood;
        int favNum;
        
        
        Scanner myScanner = new Scanner(System.in);
        
        
        System.out.println("What is your name?");
        name = myScanner.nextLine();
        
        System.out.println("What is user's name?");
        myName = myScanner.nextLine();
        
        System.out.println("Nice to meet you, " + name + "! My name is " + myName);
        
        System.out.println("What's our favorite color?");
        favColor = myScanner.nextLine();
        
        System.out.println("Oh, I just painted my room " + favColor + "!");
        
        System.out.println("What's your favorite fruit?");
        favFood = myScanner.nextLine();
        
        System.out.println("I've never tried " + favFood + "before...");
        
        System.out.println("And your favorite number?");
        favNum = Integer.parseInt(myScanner.nextLine());
        
        System.out.println(favNum + ", huh? Well on that note, BYE!");
        
    }
}
