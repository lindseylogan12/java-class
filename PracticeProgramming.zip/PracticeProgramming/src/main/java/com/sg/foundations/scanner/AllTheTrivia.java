/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.scanner;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class AllTheTrivia {
    public static void main(String[] args) {
        
        String bones, presidents, continent;
        
        Scanner myScanner = new Scanner(System.in);
        
        System.out.println("How many extra bones are in a baby's body relative to an adult's?");
        bones = myScanner.nextLine();
        
        System.out.println("How many presidents have there been?");
        presidents = myScanner.nextLine();
        
        System.out.println("Which continent is considered both a continent AND a country?");
        continent = myScanner.nextLine();
        
        
        
        
        
        
    }
 
}
