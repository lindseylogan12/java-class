/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.ifs;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class MiniZork {
    
    public static void main(String[] args) {
        
        Scanner myScanner = new Scanner(System.in); 
        
        System.out.println("Your are standing in an open field west of a white house,");
        System.out.println("with a boarded front door.");
        System.out.println("There is a small mailbox here.");
        System.out.println("Go to the house, or open the mailbox?");
        
        String action = myScanner.nextLine();
        
        if (action.equals("open the mailbox")) {
            System.out.println("You open the mailbox.");
            System.out.println("It's really dark in there.");
            System.out.println("Look inside or stick your hand in?");
            
            action = myScanner.nextLine();
            
            if (action.equals("look inside")) {
                System.out.println("You peer inside the mailbox.");
                System.out.println("It appears even darker than a black hole.");
                System.out.println("Run away or keep looking?");
                
                action = myScanner.nextLine();
                        
                if (action.equals("keep looking")) {
                    System.out.println("Bad idea to keep looking");
                    System.out.println("You've been eaten by a grue");
                }   else if (action.equals("run away")) {
                    System.out.println("You run away looking like a fool");
                    System.out.println("But you're alive - possibly a wise choice.");
                }     
            } else if (action.equals("stick your hand in")) {
                System.out.println("You've been greeted with a warmly embrace by the grue for your courage");
                System.out.println("You are luckier than the last guy!");
            }
        } else if (action.equals("go to the house")) {
            System.out.println("You approach the house... it reminds you of your grandmother's house...");
            System.out.println("The door opens, it appears to be your grandma... but... she passed away last year?");
            System.out.println("Do you go talk to her or run away?");
            
            action = myScanner.nextLine();
            
            if (action.equals("go talk to her")) {
                System.out.println("You walk up to your grandma, realize its really her, and decide to go in for a big hug!");
                System.out.println("As your arms wrap around her, you're in disbelief as you hug the air ... how could that be?");
            } else if (action.equals("run away")) {
                System.out.println("You run away as your poor grandma shouts for your help, as she appeared to have fallen to her knees");
                System.out.println("What kind of person doesn't help their grandmother in a time of need?");
            }
        } 
    }
}
