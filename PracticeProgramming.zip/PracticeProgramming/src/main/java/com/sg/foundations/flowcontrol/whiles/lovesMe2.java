/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.whiles;

import java.util.Random;

/**
 *
 * @author lindseylogan
 */
public class lovesMe2 {
    
    public static void main(String[] args) {
        
         Random myRandom = new Random();
        
        int petals = myRandom.nextInt(89) + 13;
        
        int picked = 0;
        
        System.out.println("Here it goes...");
      
        
        boolean love = true;
        
        
        while (picked <= petals){
            if (petals % 2 == 0){
                System.out.println("he loves me...");
                petals--;
                
            } else {
                System.out.println("he loves me NOT!");
                petals--;
                picked++;  
            } 
        }
        
        System.out.println(petals + " petals");
        System.out.println(picked + " picked ");
        
        //test last petal this is wrong 
        if (picked % 2 == 0) {
            System.out.println("Awww, bummer.");
        } else {
            System.out.println("I knew it! He loves me!");
        }
        
    }
}
