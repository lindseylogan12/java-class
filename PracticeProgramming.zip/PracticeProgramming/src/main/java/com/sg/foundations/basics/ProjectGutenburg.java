/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.basics;

/**
 *
 * @author lindseylogan
 */
public class ProjectGutenburg {
    public static void main(String[] args) {
        System.out.print("Did you know that in 1440 (or thereabouts),");
        System.out.print("Johannes Gutenberg invented the printing press?");
        System.out.println("He started out as a goldsmith!");
        System.out.println("His invention made it easy to print and");
        System.out.print("distribute books to anyone who wanted one.");
        System.out.println("We are like a modern Gutenberg,");
        System.out.print("printing vast amounts to the waiting console with ease.");  
    }
}
