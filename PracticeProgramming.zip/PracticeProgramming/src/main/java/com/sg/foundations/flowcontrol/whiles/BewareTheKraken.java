/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.whiles;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class BewareTheKraken {
    
    public static void main(String[] args) {
        
        
        Scanner sc = new Scanner(System.in);
        
        String action = "";
        
        System.out.println("Already, get those flippers and wetsuit on - we're going diving!");
        System.out.println("Here we goooo.....! *SPLASH*");

        int depthDivedInFt = 0;
        
        while (depthDivedInFt < 36200) {
            System.out.println("So far, we've swam " + depthDivedInFt + " feet");
            
            if (depthDivedInFt == 21000) {
                System.out.println("Uhhh, I think I see a Kraken, guys ....");
                
            }
            
            if (depthDivedInFt >= 20000) {
                System.out.println("Do you want to keep going? (y/n)");
                action = sc.nextLine();
            }
                
            
            if (action.equals("y")) {
                System.out.println("Right on!");
            } else if (action.equals("n")) {
                System.out.println("Ok, we're turning around!");
                break;
            }
            
        depthDivedInFt += 3000;
    }
        
        System.out.println("");
        System.out.println("We ended up swimming " + depthDivedInFt + " feet down.");
        System.out.println("I bet we can do better next time!");
        
}
}
