/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.whiles;

/**
 *
 * @author lindseylogan
 */
public class WaitAWhile {
    
    public static void main(String[] args) {
        
        int timeNow = 5;
        int bedTime = 11;
        
        while (timeNow < bedTime) {
            System.out.println("It's only " + timeNow);
            System.out.println("I will stay up a little longer");
            timeNow++; //time passes
        }
        
        System.out.println("Oh, it's now " + timeNow);
        System.out.println("Guess I should go to bed ...");
    }
}
