/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.whiles;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class RollerCoaster {
    
    public static void main(String[] args) {
        
        Scanner myScanner = new Scanner(System.in);
        
        System.out.println("We are going on a roller coaster!");
        System.out.println("Let me know when you want to get off!");
        
        String keepRiding = "y";
        int loopsLooped = 0;
        
        while (keepRiding.equals("y")) {
            System.out.println("Weeeee");
            System.out.print("Want to keep going? (y/n): ");
            keepRiding = myScanner.nextLine();
            loopsLooped++;
        }
        
        System.out.println("Wow, that was fun!");
        System.out.println("We looped " + loopsLooped + " times!");
    }
}
