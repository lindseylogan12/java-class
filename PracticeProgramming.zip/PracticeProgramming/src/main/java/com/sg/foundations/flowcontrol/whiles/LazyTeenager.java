/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.whiles;

import java.util.Random;

/**
 *
 * @author lindseylogan
 */
public class LazyTeenager {
    
    public static void main(String[] args) {
        
        Random newRandom = new Random();
        int probability = newRandom.nextInt(10) + 2;
        
        boolean cleanRoom = false;
        int  scold = 1;
        
        
          
        
        do 
        {
            System.out.println("Clean your room! (x" + scold + ")");
            
            if (scold == 7 && cleanRoom != true){
              System.out.println("That's it, you're grounded!");
              break;
          }
            if (probability == 10){
              cleanRoom = true;
              System.out.println("Finally, you cleaned your room!");
              break;
          }
              scold++;
              probability++;
            
           
        } while (scold < probability);
        
        
        //test!
        System.out.println("is room clean? " + cleanRoom);
        
        
        
        
        
                
        
        
        
    }
    
    
}
