/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.fors;

/**
 *
 * @author lindseylogan
 */
public class SpringForwardFallBack {
    public static void main(String[] args) {
        
        System.out.println("It's Spring...");
        for (int i = 1; i < 11; i++) {
            System.out.print(i + ", ");         // range 0-9 --- changed both but making int 0 > 1 and i < 10 to i < 11
        }
        
        System.out.println("\nOh no, it's fall...");
        for (int i = 10; i > 0; i--) {
        System.out.print(i + ", ");             // range is 10-1
    }
    }
}
