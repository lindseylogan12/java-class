/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.whiles;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class StayPositive {
    
    public static void main(String[] args) {
        
        Scanner myScanner = new Scanner(System.in);
        
        System.out.println("Please choose our starting number: ");
        int countFrom = Integer.parseInt(myScanner.nextLine());
        
        int countTo = 0;
        
        System.out.println("Counting down...");
        
        while (countFrom >= countTo) {
            System.out.println(countFrom);
            countFrom--;
            
        }
        
        System.out.println("Blast off!");
    }
}
