/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.ending.exercises;


import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class Factorizer {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("What number would you like to factor?: ");
        int number = sc.nextInt();
        
        
        int factors = 0; // counter to keep track of factors
        int factorArr[] = new int[number];
        int answer = 0;
        
        for (int i = 1; i <= number; i++){
            if(number % i == 0) {
                factors++;
                System.out.println("The factors of " + number + " are: " + i);
            }
        }
        System.out.println(number + " has " + factors + " factors.");
       
    }
}
