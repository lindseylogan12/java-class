/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.scanner;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class DoItBetter {
    public static void main(String[] args) {
        
        int miles, hotdogs, doBetter;
  
        
        Scanner myScanner = new Scanner(System.in);
        
        
        System.out.println("How many miles can you run?");
        miles = Integer.parseInt(myScanner.nextLine());
        
        doBetter = miles * 2 + 1;
        
        System.out.println("Wow, that's a lot of miles. Maybe one day you'll be able to do as many as me ... " + doBetter);
        
        System.out.println("How about how many hotdogs can you eat?");
        hotdogs = Integer.parseInt(myScanner.nextLine());
        
        doBetter = hotdogs * 2 + 1;
        
        System.out.println("That's barely anything. Talk to me when you can eat " + doBetter);
       
    }
}
