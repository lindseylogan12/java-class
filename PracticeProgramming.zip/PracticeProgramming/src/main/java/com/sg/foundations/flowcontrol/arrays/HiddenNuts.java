/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.arrays;

import java.util.Random;

/**
 *
 * @author lindseylogan
 */
public class HiddenNuts {
    
    public static void main(String[] args) {

        String[] hidingSpots = new String[100];
        Random squirrel = new Random();
        hidingSpots[squirrel.nextInt(hidingSpots.length)] = "Nut";
        System.out.println("The nut has been hidden ...");

        // Nut finding code should go here! 
        
        for (int i = 0; i < hidingSpots.length; i++){
            if (hidingSpots[i] != null && hidingSpots[i].equalsIgnoreCase("Nut")){
                System.out.println("Found it! It's in spot # " + (i+1));
                break;
                } else {
                System.out.println("Not found at spot # " + (i+1));
                }
        }
    }
}
