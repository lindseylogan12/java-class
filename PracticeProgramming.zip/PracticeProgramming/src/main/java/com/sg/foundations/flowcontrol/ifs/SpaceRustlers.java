/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.ifs;

/**
 *
 * @author lindseylogan
 */
public class SpaceRustlers {
    
    public static void main(String[] args) {
    
        int spaceships = 10;
        int aliens = 25;
        int cows = 100;
        
        if (aliens > spaceships) {
            System.out.println("Let's get going!");
        } else { // means "otherwise... execute this
            System.out.println("There aren't enough green guys to drive this ship ...");
        }
        
        if (cows == spaceships) {
            System.out.println("Barely enough room for all these walking hamburgers");
        } else if (cows > spaceships) { //if the first condition isnt met, see if this new condition is
            System.out.println("We can't fit all of these cows in here");
        } else { // if new condition isn't met either, execute this one
            System.out.println("Too many ships! Not enough cows!");
        }
        
        if (aliens > cows) {
            System.out.println("Hurrah, hamburger party coming soon!");
        } else if (cows >= aliens) {
            System.out.println("Oh no... the herds are restless and took over!");
        }
        
    }
}
