/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.random;

import java.util.Random;

/**
 *
 * @author lindseylogan
 */
public class CoinFlipper {
    
    public static void main(String[] args) {
        
        Random myRandom = new Random();
        
        Boolean x = myRandom.nextBoolean();
        
        
        System.out.println("Ready, set, flip!");
        
        if (x.equals("true")) {
            System.out.println("You got HEADS!");
        } else {
            System.out.println("You got TAILS!");
        }
        
    
    }
}
