/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.variables;

/**
 *
 * @author lindseylogan
 */
public class AllAboutMe {
    public static void main(String[] args) {
        String name, favFood, homeType, whistle;
        int pets;
        
        name = "Lindsey";
        favFood = "green beans";
        homeType = "house";
        whistle = "no";
        pets = 3;
        
        System.out.println("Hello my name is " + name + ", and my favorite food is " + favFood + '.');
        System.out.println("I have " + pets + " pets that live in my " + homeType + " with me. When people ask if I know how to whistle, I say " + whistle);
    }
}
