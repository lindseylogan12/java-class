/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.random;

import java.util.Random;

/**
 *
 * @author lindseylogan
 */
public class Opinionator {
    
    public static void main(String[] args) {
        
        Random randomizer = new Random();
        
        System.out.println("I can't decide what animal I like best.");
        System.out.println("Random shall decide for me");
        
        int x = randomizer.nextInt(5);
        
        System.out.println("The number we choose was: " + x);
        
        switch (x) {
            case 0:
                System.out.println("LLamas are the best!");
                break;
            case 1:
                System.out.println("Dodos are the best!");
                break;
            case 2:
            case 3:
            case 4:
                System.out.println("I want to be a zebra");
                break;
            case 5:
                System.out.println("Naked mole rat!");
                break;
        }
        
        System.out.println("Thanks, random, maybe youre the best!");
    }
}
