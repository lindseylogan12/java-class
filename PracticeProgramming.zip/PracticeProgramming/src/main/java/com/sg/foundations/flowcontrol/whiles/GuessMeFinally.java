/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.whiles;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class GuessMeFinally {
    
    public static void main(String[] args) {
        
        Random myRandom = new Random();
        
        int userChoice;
        
        int choice = myRandom.nextInt(100 - -100) - 100;
        
        Scanner myScanner = new Scanner(System.in); 
        
        System.out.println("Please pick a whole number between -100 and 100 and enter it below: ");
        userChoice = Integer.parseInt(myScanner.nextLine());
        
        System.out.println("You entered: " + userChoice);
        
       while (userChoice != choice) {
       
        
        if (userChoice < choice) {
            System.out.println("Too low - try again:");
            userChoice = Integer.parseInt(myScanner.nextLine());
            System.out.println("Your guess: " + userChoice);
           
        }
        
        else if (userChoice > choice) {
            System.out.println("Too high - try again:");
            userChoice = Integer.parseInt(myScanner.nextLine());
            System.out.println("Your guess: " + userChoice);
            
        }
         
        if (userChoice == choice) {
            System.out.println("You finally guessed my number!");
            System.out.println("Your guess: " + userChoice);
        }
        
      }
       
      
}
}
