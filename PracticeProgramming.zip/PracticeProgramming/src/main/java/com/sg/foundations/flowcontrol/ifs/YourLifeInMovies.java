/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.ifs;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class YourLifeInMovies {
    public static void main(String[] args) {
        
        int year;
        
        Scanner myScanner = new Scanner(System.in);
        
        System.out.println("Let's play a game ... please enter the year you were born: ");
        year = Integer.parseInt(myScanner.nextLine());
        
        if (year < 2005) {
            System.out.println("Pixar's 'Up' came out over a decade ago.");
        }
        
        if (year < 1995) {
            System.out.println("The first Harry Potter movie came out over 15 years ago.");
        }
        
        if (year < 1985) {
            System.out.println("Space Jam came out not one decade ago ... but TWO decades ago!");
        }
    }
}
