/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.scanner;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class BiggerBetterAdder {
    public static void main(String[] args) {
        
        int value1, value2, value3, sum; 
        
        Scanner myScanner = new Scanner(System.in);
        
        System.out.println("Please enter a number 1-10 three times:");
        value1 = Integer.parseInt(myScanner.nextLine());
        value2 = Integer.parseInt(myScanner.nextLine());
        value3 = Integer.parseInt(myScanner.nextLine());
        
        System.out.println("You entered:");
        System.out.println(value1);
        System.out.println(value2);
        System.out.println(value3);
        
        sum = value1 + value2 + value3;
        
        System.out.println("These numbers added together equal:");
        System.out.println(sum);
    }
    
    
}
