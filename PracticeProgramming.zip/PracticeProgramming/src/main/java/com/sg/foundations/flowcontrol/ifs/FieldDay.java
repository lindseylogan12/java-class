/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.ifs;

import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class FieldDay {
    
    public static void main(String[] args) {
        
        String baggins = "Baggins";
        String dresden = "Dresden";
        String howl = "Howl";
        String potter = "Potter";
        String vimes = "Vimes";
    
        
        Scanner myScanner = new Scanner(System.in);
        
        System.out.println("What is your last name?");
        String lastName = myScanner.nextLine();
        
        //conditionals below
        
        if (lastName.compareTo(baggins) < 0) {
            System.out.println("Your team is Red Dragons");
        } else if (lastName.compareTo(dresden) < 0) {
            System.out.println("Your team is Dark Wizards");
        } else if (lastName.compareTo(howl) < 0) {
            System.out.println("Your team is Moving Castles");
        } else if (lastName.compareTo(potter) < 0) {
            System.out.println("Your team is Golden Snitches");
        } else if (lastName.compareTo(vimes) < 0) {
            System.out.println("Your teams is Night Guards");
        } else {
            System.out.println("Your team is Black Holes");
        }
    }
}
