/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sg.foundations.flowcontrol.random;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author lindseylogan
 */
public class HighRoller {
 
    public static void main(String[] args) {
        
        Random myRandom = new Random();
        Scanner myScanner = new Scanner(System.in);
        
        
        System.out.println("How many sides are there on a single dice?");
        int sides = Integer.parseInt(myScanner.nextLine());
        
        int roll = myRandom.nextInt(sides) + 1; //this means 6 inclusive?
        
        
        System.out.println("Time to roll the dice :D");
        System.out.println("I rolled a " + roll);
        
        if (roll == 1) {
            System.out.println("You rolled a critical failure!");
        } else if (roll == 6) {
            System.out.println("Nice, you must be lucky!");
        }
    }
}
